# Code-Quiz
## Description
A timer-based quiz application that stores high scores client-side.

## Description
A timer-based quiz application that stores high scores client-side.

### Table of Contents
* [Installation](#installation)
* [Technologies-Libraries](#technologies-libraries)
* [Demo](#demo)
* [Credits](#credits)

## Installation
In your terminal type:
```git clone https://verlitas.github.io/Code-Quiz/```
* Open in Visual Studio to build and run.
* For further instructions, visit https://help.github.com.

## Technologies-Libraries
CSS - HTML - JavaScript

## Demo
![livedemo](img/codequiz.gif)
Live Link: https://verlitas.github.io/Code-Quiz/

## Credits
[Melody Kirshberg](https://github.com/verlitas)  
[UABootCamp](https://bootcamp.ce.arizona.edu/coding/)  
