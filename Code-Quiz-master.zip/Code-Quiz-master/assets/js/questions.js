var questions = [
    {
        title: "How many programming languages are there?",
        choices: ["698", "674", "482", "36"],
        answer: "698"
    },
    {
        title: "Who was the first computer programmer?",
        choices: ["Dennis Ritchie", "Ada Lovelace", "Alan Turing", "Tim Berners-Lee"],
        answer: "Ada Lovelace"
    },
    {
        title: "What was the first high-level programming language",
        choices: ["Plankalkul", "Java", "C", "Short Code"],
        answer: "Short Code"
    },
    {
        title: "What was the name of the first computer?",
        choices: ["ENIAC", "Colossus", "Abacus", "Ada"],
        answer: "Colossus"
    },
    {
        title: "What was the name of the first automated computer compiler?",
        choices: ["IBM", "ALGOL", "A-o", "Autocoder"],
        answer: "A-o"
    }
];